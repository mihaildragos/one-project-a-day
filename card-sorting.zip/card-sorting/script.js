const categoriesWrapper = document.querySelector('.right');
const addCategory = document.querySelector('.add');



function setListeners() {
  let categoryNames = document.querySelectorAll('h3.cat-name');
  categoryNames.forEach(name => {
    name.addEventListener('dblclick', function (e) {
      var val=this.innerHTML.trim();
      console.log(val);
      var input=document.createElement("input");
      input.value=val;
      input.onblur=function(){
        var val=this.value;
        this.parentNode.innerHTML=val;
      }
      this.innerHTML="";
      this.appendChild(input);
      input.focus();
    })
  });
  
  let closeCategory = document.querySelectorAll('.cat-close');
  closeCategory.forEach(cat => {
    cat.addEventListener('click', (e) => {
      let node = e.target.parentNode;
      categoriesWrapper.removeChild(node);
      setListeners();
    });
  })
}

addCategory.addEventListener('click', (e) => {
  let categoryNode = document.querySelector('.sample').cloneNode(true);
  let newNode = categoryNode;
  categoriesWrapper.appendChild(newNode);
  let hiddenCat = document.querySelectorAll('.sample');
  hiddenCat[1].classList.remove('sample');
  categoriesWrapper.appendChild(addCategory);
  setListeners();
});


sortable('.left, .cat-content', {
  items: '.item',
  acceptFrom: '.cat-content, .left '
});

setListeners();


